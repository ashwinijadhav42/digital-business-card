import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import SoftwareEngineer from "./SoftwareEngineer";
import BusinessAnalystCard from "./BusinessAnalyst";

function ViewCard() {
  const { slug } = useParams();
  const [card, setCard] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:8080/api/corporate-cards/${slug}`)
      .then((res) => res.json())
      .then((data) => {
        console.log("API RESPONSE:", data);
        setCard(data);
      })
      .catch((err) => console.error(err));
  }, [slug]);

  if (!card) return <h3>Loading...</h3>;

  return (
    <div style={{ padding: "20px" }}>
      <h2>Card Preview</h2>

      <h4>Template: {card.templateType}</h4>

      {card.templateType === "business" && (
        <BusinessAnalystCard data={card} />
      )}

      {card.templateType === "software" && (
        <SoftwareEngineer data={card} />
      )}
    </div>
  );
}

export default ViewCard;